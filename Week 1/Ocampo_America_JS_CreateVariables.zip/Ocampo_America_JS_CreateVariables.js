var minimumHeight = 42;
var minimumAge = 10;
I created a variable for Minimum Height as a numeric value of 42 because we will need to create a mathematical formula or equation for this variable.
I created a variable for Minimum Age as a numeric value of 10 because we will also need to create a mathematical formula or equation for this variable.
